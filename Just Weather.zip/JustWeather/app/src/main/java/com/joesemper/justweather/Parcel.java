package com.joesemper.justweather;

import java.io.Serializable;

public class Parcel implements Serializable {
    boolean isPressureOn;
    boolean isWindOn;
    String location = "";
}
