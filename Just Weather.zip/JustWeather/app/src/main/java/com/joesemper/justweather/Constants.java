package com.joesemper.justweather;

public interface Constants {
    public static final String SETTINGS = "SETTINGS";
    public static final Integer REQUEST_CODE = 1;
    public static final Integer OK = 2;
}
